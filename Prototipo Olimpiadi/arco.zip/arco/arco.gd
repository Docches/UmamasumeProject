extends Node2D

const PULL_STRENGTH: float = 5.0
const WIN_LIMIT_LEFT: float = 350.0
const WIN_LIMIT_RIGHT: float = 800.0

enum GameState { TUTORIAL, WAITING, COUNTDOWN, PLAYING, ENDED }

@export var immagine_fazzoletto: Texture2D
@export var immagine_team_sinistra: Texture2D
@export var immagine_team_destra: Texture2D

@onready var fazzoletto: Sprite2D = $Fazzoletto
@onready var status_label: Label = $UI/StatusLabel
@onready var countdown_label: Label = $UI/CountdownLabel
@onready var tutorial_panel: ColorRect = $UI/TutorialPanel
@onready var team_sx_label: Label = $UI/TutorialPanel/TeamSinistraText
@onready var team_dx_label: Label = $UI/TutorialPanel/TeamDestraText

var bot_timers: Dictionary = {}
var local_players_data: Array = []
var current_state: int = GameState.TUTORIAL
var tween_fazzoletto: Tween
var standalone_test: bool = false

func _ready() -> void:
	countdown_label.text = ""
	status_label.text = ""
	tutorial_panel.show()
	
	_applica_sprite_personalizzati()
	_inizializza_rete_e_giocatori()
	_compila_testi_tutorial()
	
	if multiplayer.is_server():
		_avvia_routine()

func _compila_testi_tutorial() -> void:
	var testo_sx = "TEAM SINISTRA:\n"
	var testo_dx = "TEAM DESTRA:\n"
	
	for i in range(local_players_data.size()):
		var p = local_players_data[i]
		var nome = "Bot " + str(i+1) if p.get("is_bot", false) else "Giocatore " + str(i+1)
		
		if i < 2:
			testo_sx += nome + "\n"
		else:
			testo_dx += nome + "\n"
			
	team_sx_label.text = testo_sx
	team_dx_label.text = testo_dx

func _avvia_routine() -> void:
	# Aspetta 4.5 secondi per far leggere i comandi e i team
	await get_tree().create_timer(4.5).timeout
	rpc("nascondi_tutorial")
	start_game_routine()

@rpc("authority", "call_local", "reliable")
func nascondi_tutorial() -> void:
	tutorial_panel.hide()

func _applica_sprite_personalizzati() -> void:
	if immagine_fazzoletto:
		fazzoletto.texture = immagine_fazzoletto
		fazzoletto.modulate = Color.WHITE
		
	if immagine_team_sinistra:
		$TeamSinistra/Player0.texture = immagine_team_sinistra
		$TeamSinistra/Player1.texture = immagine_team_sinistra
		$TeamSinistra/Player0.modulate = Color.WHITE
		$TeamSinistra/Player1.modulate = Color.WHITE
		
	if immagine_team_destra:
		$TeamDestra/Player2.texture = immagine_team_destra
		$TeamDestra/Player3.texture = immagine_team_destra
		$TeamDestra/Player2.modulate = Color.WHITE
		$TeamDestra/Player3.modulate = Color.WHITE

func _inizializza_rete_e_giocatori() -> void:
	var global_data_node = get_node_or_null("/root/GlobalData")
	
	if global_data_node and "players_data" in global_data_node and not global_data_node.players_data.is_empty():
		local_players_data = global_data_node.players_data
	else:
		standalone_test = true
		_avvia_server_mock_f6()

	for i in range(local_players_data.size()):
		var p: Dictionary = local_players_data[i]
		if multiplayer.is_server() and p.get("is_bot", false):
			bot_timers[i] = randf_range(0.15, 0.25)

func _avvia_server_mock_f6() -> void:
	if multiplayer.multiplayer_peer == null or multiplayer.multiplayer_peer.get_connection_status() == MultiplayerPeer.CONNECTION_DISCONNECTED:
		var peer = ENetMultiplayerPeer.new()
		peer.create_server(randi_range(10000, 20000))
		multiplayer.multiplayer_peer = peer
		
	local_players_data = [
		{"id": 1, "is_bot": false}, 
		{"id": 0, "is_bot": true},  
		{"id": 0, "is_bot": true},  
		{"id": 0, "is_bot": true}   
	]

func start_game_routine() -> void:
	rpc("sync_state", GameState.COUNTDOWN)
	for i in range(3, 0, -1):
		rpc("sync_countdown", str(i))
		await get_tree().create_timer(1.0).timeout
		
	rpc("sync_countdown", "SPAMMA SPAZIO!")
	rpc("sync_state", GameState.PLAYING)
	
	await get_tree().create_timer(1.0).timeout
	if current_state == GameState.PLAYING:
		rpc("sync_countdown", "")

@rpc("authority", "call_local", "reliable")
func sync_state(new_state: int) -> void:
	current_state = new_state
	match current_state:
		GameState.COUNTDOWN:
			status_label.text = "PREPARATI..."
		GameState.PLAYING:
			status_label.text = "TIRA!"

@rpc("authority", "call_local", "reliable")
func sync_countdown(text: String) -> void:
	countdown_label.text = text

func _unhandled_input(event: InputEvent) -> void:
	if current_state != GameState.PLAYING:
		return
		
	if event.is_action_pressed("ui_accept", false) and not event.is_echo():
		var local_id = multiplayer.get_unique_id()
		if not _is_local_player_a_bot(local_id):
			rpc_id(1, "receive_pull")

func _process(delta: float) -> void:
	if current_state != GameState.PLAYING or not multiplayer.is_server():
		return
		
	for bot_index in bot_timers.keys():
		bot_timers[bot_index] -= delta
		if bot_timers[bot_index] <= 0.0:
			_process_pull_logic_by_slot(bot_index)
			bot_timers[bot_index] = randf_range(0.18, 0.28)

func _is_local_player_a_bot(id: int) -> bool:
	for p in local_players_data:
		if p["id"] == id:
			return p.get("is_bot", false)
	return false

@rpc("any_peer", "call_local", "reliable")
func receive_pull() -> void:
	if current_state != GameState.PLAYING or not multiplayer.is_server():
		return
	var sender_id = multiplayer.get_remote_sender_id()
	
	var slot = -1
	for i in range(local_players_data.size()):
		if local_players_data[i]["id"] == sender_id:
			slot = i
			break
			
	if slot != -1:
		_process_pull_logic_by_slot(slot)

func _process_pull_logic_by_slot(slot: int) -> void:
	if current_state != GameState.PLAYING:
		return
		
	if slot == 0 or slot == 1:
		fazzoletto.position.x -= PULL_STRENGTH
	elif slot == 2 or slot == 3:
		fazzoletto.position.x += PULL_STRENGTH
		
	rpc("sync_fazzoletto", fazzoletto.position.x)
	_check_win_condition()

@rpc("authority", "call_local", "unreliable_ordered")
func sync_fazzoletto(new_x: float) -> void:
	if tween_fazzoletto and tween_fazzoletto.is_running():
		tween_fazzoletto.kill()
		
	tween_fazzoletto = create_tween()
	tween_fazzoletto.tween_property(fazzoletto, "position:x", new_x, 0.08).set_trans(Tween.TRANS_SINE)

func _check_win_condition() -> void:
	if fazzoletto.position.x <= WIN_LIMIT_LEFT:
		declare_winner("SINISTRA", [0, 1])
	elif fazzoletto.position.x >= WIN_LIMIT_RIGHT:
		declare_winner("DESTRA", [2, 3])

func declare_winner(team_name: String, winner_slots: Array[int]) -> void:
	current_state = GameState.ENDED
	rpc("sync_state", GameState.ENDED)
	
	var global_data_node = get_node_or_null("/root/GlobalData")
	if global_data_node:
		global_data_node.minigame_winners = winner_slots.duplicate()
		
	rpc("show_winner_ui", team_name)
	
	await get_tree().create_timer(3.0).timeout
	
	if standalone_test:
		multiplayer.multiplayer_peer = null
		if global_data_node:
			global_data_node.players_data.clear()
		get_tree().reload_current_scene()
	else:
		rpc("ritorna_al_tabellone")

@rpc("authority", "call_local", "reliable")
func show_winner_ui(team_name: String) -> void:
	status_label.text = "VITTORIA DEL TEAM " + team_name + "!"
	countdown_label.text = ""

@rpc("authority", "call_local", "reliable")
func ritorna_al_tabellone() -> void:
	get_tree().change_scene_to_file("res://tabellone/tabellone.tscn")
